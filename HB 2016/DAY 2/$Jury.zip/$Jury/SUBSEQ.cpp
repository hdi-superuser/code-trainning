#include <bits/stdc++.h>
#define maxn 1000005

using namespace std;

int n, k, a[maxn], s[maxn];

int main() {
    freopen("subseq.inp","r",stdin);
    freopen("subseq.out","w",stdout);
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++) scanf("%d",a+i);
    s[0]=0;
    for(int i=1;i<=n;i++) s[i]=s[i-1]+a[i];
    int smin=s[0], ans=s[k];
    for(int i=k+1;i<=n;i++) {
        smin=min(smin,s[i-k]);
        ans=max(ans,s[i]-smin);
    }
    printf("%d",ans);
}
