//Dai Ca Di Hoc
#include <bits/stdc++.h>
#define sz(x) int(x.size())
#define MIN(x,y) if (x > y) x = y
#define PB push_back
#define mp make_pair
#define F first
#define S second
#define Task "advert"
#define maxn 100001
#define MOD 1000000007
#define remain(x) if (x > MOD) x -= MOD
#define pii pair<int, int>

using namespace std;

int n;
double w, h;
int a[maxn], b[maxn];

bool check(double val)
{
    double cao = 0;
    int j = 1;
    for (int i = 1; i <= n;)
    {
        double dai = 0;
        for (j = i; j <= n && dai + val*a[j] <= w && b[j] == b[i]; j++)
            dai += val * a[j];
        cao += val * b[i];
        if (i == j || cao > h) return 0;
        i = j;
    }
    return 1;
}

int main()
{
	//ios_base::sync_with_stdio(0);
    freopen(Task".inp", "r", stdin);
    freopen(Task".out", "w", stdout);
    scanf("%d%lf%lf", &n, &w, &h);
    for (int i = 1; i <= n; i++) scanf("%d%d", &a[i], &b[i]);
    double l = 0;
    double r = w;
    while (r-l > 1e-8)
    {
        //printf("%0.9f %0.9f\n", l, r);
        double mid = (l+r)/2;
        if (check(mid)) l = mid;
            else r = mid;
    }
    printf("%0.6f", l);
    return 0;
}
