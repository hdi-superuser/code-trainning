#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <cstring>
#include <fstream>
#include <algorithm>
#include <queue>
#include <utility>
#include <vector>
#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define maxn 1003
#define task "advert"

typedef char NameFile[1000];

using namespace std;

NameFile input, output, answer;
ifstream fi, fo, fa;


int read()
{

}

int readInput()
{
  fi.open(input);
}

int readOutput()
{
  fo.open(output);
}

int readAnswer()
{
  fa.open(answer);
}

bool check()
{
  double ans, out;
  fo >> out;
  fa >> ans;

  if (abs(out-ans) > 1e-6)
  {
      cout << " Ket qua sai!!\n";
      cout << " Output is: " << out << endl;
      cout << " Answer is: " << ans << endl;
      return 0;
  }
// others here

  cout << " Ket qua dung!!! \n";
  printf("ans = %0.9f \n out = %0.9f\n", ans, out);
  return 1;
}

main()
{
  gets(input);
  gets(output);

  strcpy(answer, input);
  strcat(input,  task".inp");
  strcat(output, task".out");
  strcat(answer, task".out");

  readInput();
  readOutput();
  readAnswer();
  read();

  cout << ((check()) ? "1.00" : "0.00");
  fi.close();
  fo.close();
  fa.close();
//  system("pause");
}
