#include <bits/stdc++.h>

#define x first
#define y second

using namespace std;

typedef unsigned long long ll;
typedef pair<int, ll> hash_t;

const int N = 300001;
const int base = 1000000007;

int n, m;
char b[N];
ll M[N];

hash_t add(hash_t a, hash_t b) {
    hash_t c;
    c.x = a.x + b.x;
    c.y = (a.y*M[a.x] + b.y) % base;
    return c;
}

//struct segment_tree {
    hash_t T[4*N];
    void build(int x, int L, int R) {
        if (L == R) {
            T[x] = hash_t(1, b[L]);
            return;
        }
        int mid = (L + R) >> 1;
        build(2*x, L, mid);
        build(2*x+1, mid+1, R);
        T[x] = add(T[2*x], T[2*x+1]);
    }

    void remove(int u, int L, int R, int k) {
        if (L > k || R < k) return;
        if (L == R) {
            T[k] = hash_t(0, 0);
            return;
        }
        remove(2*u+1, L+T[2*u].x, R, k);
        remove(2*u, L, L+T[2*u].x-1, k);
    }

    hash_t hash_range(int u, int ll, int rr, int L, int R) {
        if (L > rr || ll > R) return hash_t(0, 0);
        if (ll >= L && rr <= R) return T[u];
        hash_t left = hash_range(2*u+1, L+T[2*u].x, R, L, R);
        hash_t right = hash_range(2*u, L, L+T[2*u].x-1, L, R);
        return add(left, right);
    }
//} it;

int main() {
    //freopen("in.txt", "r", stdin);
    scanf("%s", b+1);
    n = strlen(b+1);
    M[0] = 1; M[1] = 2309;
    for (int i = 2; i <= n; i++) M[i] = M[i-1] * M[1];

    build(1, 1, n);
    scanf("%d\n", &m);
    for (int i = 1; i <= m; i++) {
        char c; int x, y, z;
        scanf(" %c%d", &c, &x);
        if (c == '-') remove(1, 1, n, x);
        else {
            scanf(" %d%d", &y, &z);
            hash_t H1 = hash_range(1, 1, n, x, x+z-1);
            hash_t H2 = hash_range(1, 1, n, y, y+z-1);
            printf(H1 == H2 ? "YES" : "NO"); printf("\n");
        }
    }
    return 0;
}

