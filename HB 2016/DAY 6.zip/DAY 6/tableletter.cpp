#include <bits/stdc++.h>

using namespace std;

const int N = 1001;
const int M = 1000000007;

char a[N][N];
int m, n;
long long H[N];

bool distinct(long long a[], int n) {
    vector<long long> T(a+1, a+n+1);
    sort(T.begin(), T.end());
    for (int i = 1; i < T.size(); i++)
        if (T[i] == T[i-1]) return false;
    return true;
}

int main() {
    //freopen("in.txt", "r", stdin);
    cin >> m >> n;
    for (int i = 1; i <= m; i++) scanf("%s", a[i] + 1);

    for (int i = m; i >= 1; i--) {
        for (int j = 1; j <= n; j++)
            H[j] = H[j]*M + a[i][j];
        if (distinct(H, n)) {
            cout << i-1 << endl;
            return 0;
        }
    }
    return 0;
}
