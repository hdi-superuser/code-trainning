#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const int base = 1000000007;

int a[301][301];
ll H[301][301], POW[301];
int n, m;

bool ok(int k) {
    for (int i = 1; i <= m-k+1; i++)
        for (int j = 1; j <= n-k+1; j++) {

        }
}

int main() {
    freopen("in.txt", "r", stdin);
    cin >> m >> n;
    for (int i = 1; i <= m; i++) {
        string str;
        cin >> str;
        for (int i = 0; i < n; i++)
            a[i][j+1] = str[j] - 48;
    }

    POW[0] = 1;
    for (int i = 1; i <= n; i++) POW[i] = POW[i-1] * 29 % base;
    for (int i = 1; i <= m; i++) {
        H[1] = 1;
        for (int i = 2; i <= n; i++)
            H[i][j] = (H[i][j-1]*POW[j] + a[i][j]) % base;
    }

    int L = 1, R = 300, mid = (L + R + 1) >> 1;
    while (L < R) {
        if (ok(mid)) L = mid;
        else R = mid - 1;
        mid = (L + R + 1) >> 1;
    }
}
