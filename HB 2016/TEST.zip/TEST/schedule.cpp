#include <bits/stdc++.h>

using namespace std;

const int N = 100001;
const int inf = 2000000001;

long long d,  a[N], b[N], c[N], res[N], best;
int n;

void minimize() {
    long long MIN = inf, MAX = -inf;
    for (int i = 1; i <= n; i++)
        MIN = min(b[i], MIN),
        MAX = max(b[i], MAX);
    if (MAX - MIN < best) {
        for (int i = 1; i <= n; i++) res[i] = b[i];
        best = MAX - MIN;
    }
}

void backtrack(int i, long long sd) {
    if (i == n) {
        long long x = d - sd;
        if (x >= a[i] && x <= c[i]) {
            b[i] = x;
            minimize();
        }
        return;
    }

    for (long long j = a[i]; j <= c[i]; j++)
        if (sd + j <= d) {
            b[i] = j;
            backtrack(i+1, sd + j);
        }
}

int main() {
    freopen("SCHEDULE.INP", "r", stdin);
    freopen("SCHEDULE.OUT", "w", stdout);
    cin >> n >> d;
    best = inf;
    for (int i = 1; i <= n; i++) cin >> a[i] >> c[i];
    backtrack(1, 0);
    if (best == inf) cout << "-1";
    else for (int i = 1; i <= n; i++) cout << res[i] << endl;
    return 0;
}

