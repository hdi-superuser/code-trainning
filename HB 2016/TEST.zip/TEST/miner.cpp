#include <bits/stdc++.h>

using namespace std;

const int N = 301;
const int inf = 2000000001;

int a[N][N], b[N][N], m, n, k;
int it[N][4*N];

void Build(int op, int x, int L, int R) {
    if (L == R) {
        it[op][x] = a[op][L];
    } else {
        int mid = (L + R) >> 1;
        Build(op, 2*x, L, mid);
        Build(op, 2*x+1, mid+1, R);
        it[op][x] = max(it[op][2*x], it[op][2*x+1]);
    }
}

int getMax(int op, int x, int L, int R, int u, int v) {
    if (L > v || R < u) return -inf;
    if (L >= u && R <= v) return it[op][x];
    int mid = (L + R) >> 1;
    int left = getMax(op, 2*x, L, mid, u, v);
    int right = getMax(op, 2*x+1, mid+1, R, u, v);
    return max(left, right);
}

int main() {
    freopen("MINER.INP", "r", stdin);
    freopen("MINER.OUT", "w", stdout);
    cin >> m >> n >> k;
    for (int i = 1; i <= m; i++)
        for (int j = 1; j <= n; j++)
            cin >> a[i][j];
    for (int i = 1; i <= m; i++) Build(i, 1, 1, n);
    for (int i = 1; i <= m; i++)
        for (int c = 1; c <= n; c++) {
            int j = c;
            int t = k, x = max(1, i-k);
            int ans = a[x][j];
            for (int y = i; y >= x; y--) {
                ans = max(ans, getMax(y, 1, 1, n, max(j-t, 1), j));
                ans = max(ans, getMax(y, 1, 1, n, j, min(j+t, n)));
                t--;
            }
            x = min(m, i+k);
            ans = max(ans, a[x][j]);
            t = k-1;
            for (int y = i + 1; y <= x; y++) {
                ans = max(ans, getMax(y, 1, 1, n, max(j-t, 1), j));
                ans = max(ans, getMax(y, 1, 1, n, j, min(j+t, n)));
                t--;
            }
            b[i][c] = ans;
        }
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) cout << b[i][j] << " ";
        cout << endl;
    }
    return 0;
}

