#include <bits/stdc++.h>

using namespace std;

const int N = 501;
const int dx[4] = {-1, 0, +1, 0};
const int dy[4] = {0, +1, 0, -1};

typedef pair<int, int> ii;

int m, n, k;
int a[N][N], d[N][N], fr[N][N];
long long b[N][N];

void bfs(int xx, int yy) {
    queue<ii> q;
    q.push(ii(xx, yy));
    memset(d, 0, sizeof d);
    memset(fr, 0, sizeof fr);
    fr[xx][yy] = 1;
    d[xx][yy] = 0;
    b[xx][yy] = a[xx][yy];
    long long sum = 0;
    while (!q.empty()) {
        ii u = q.front(); q.pop();
        int x = u.first, y = u.second;
        for (int t = 0; t < 4; t++) {
            int nx = x + dx[t], ny = y + dy[t];
            if (nx <= 0 || nx > m || ny <= 0 || ny > n) continue;
            if (fr[nx][ny]) continue;
            fr[nx][ny] = 1;
            if (d[x][y] + 1 <= k) {
                d[nx][ny] = d[x][y] + 1;
                b[xx][yy] = max(b[xx][yy], 1LL*a[nx][ny]);
                if (d[nx][ny] < k) q.push(ii(nx, ny));
            }
        }
    }
}

int main() {
    freopen("MINER.INP", "r", stdin);
    freopen("MINER.OUT", "w", stdout);
    cin >> m >> n >> k;
    for (int i = 1; i <= m; i++)
        for (int j = 1; j <= n; j++)
            cin >> a[i][j];
    for (int i = 1; i <= m; i++)
        for (int j = 1; j <= n; j++)
            bfs(i, j);
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++)
            cout << b[i][j] << " ";
        cout << endl;
    }
    return 0;
}

