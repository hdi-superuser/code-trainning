#include <bits/stdc++.h>

using namespace std;

int a[1000001], n;

int main() {
    freopen("TWOVALS.INP", "r", stdin);
    freopen("TWOVALS.OUT", "w", stdout);
    scanf("%d\n", &n);
    int ans = 0;
    for (int i = 1; i <= n; i++) scanf("%d ", &a[i]);
    for (int i = 2; i <= n; i++) {
        set<int> s;
        for (int j = i; j >= 1; j--) {
            s.insert(a[j]);
            if (s.size() > 2) {
                ans = max(ans, i - j);
		break;
            }
        }
        if (s.size() == 2) ans = max(ans, i);
    }
    printf("%d", ans);
    return 0;
}

