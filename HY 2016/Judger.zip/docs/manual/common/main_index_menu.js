
document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li ><a href=\"index.html\"           target=\"_top\">Return Document Home Page</a>   </li>');
document.write('<li ><a href=\"index_main.html\"      target=\"_top\">Home <span class="speed_arrow">&raquo;</span>   </a>   </li>');

document.write('<li ><a href=\"#Quick Start\"         target=\"_top\">Quick Start <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Server Utilities\"    target=\"_top\">Server Utilities<span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#General\"             target=\"_top\">General <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Extra\"               target=\"_top\">Extra<span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Apache\"              target=\"_top\">Apache <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#MySQL\"               target=\"_top\">MySQL <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#PHP\"                 target=\"_top\">PHP <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Perl\"                target=\"_top\">Perl <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Multi-Servers\"       target=\"_top\">Multi-Servers <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Portable Browser\"    target=\"_top\">Portable Browser <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Applications - Installing\"    target=\"_top\">Applications - Installing <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Run as service\"    target=\"_top\">Run as service <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#MySQL Auto DB Backup\"    target=\"_top\">MySQL Auto DB Backup <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Portable FileZilla Server\"    target=\"_top\">Portable FileZilla Server <span class="speed_arrow">&raquo;</span></a></li>');

document.write('</ul>');
document.write('</div>');
