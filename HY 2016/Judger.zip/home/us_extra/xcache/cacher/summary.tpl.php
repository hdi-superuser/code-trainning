<?php include "../common/header.tpl.php"; ?>
<div class="switcher"><?php echo switcher("do", $doTypes); ?></div>
<?php include "./sub/summary.tpl.php"; ?>
<?php include "./sub/moduleinfo.tpl.php"; ?>
<?php include "../common/footer.tpl.php"; ?>
