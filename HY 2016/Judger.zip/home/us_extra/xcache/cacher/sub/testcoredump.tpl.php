<form method="post" action=""
	><div
		><input type="submit" name="coredump" value="Test coredump" class="submit" onclick="return confirm('<?php echo _T('Sure?'); ?>');"
	/></div
></form>
