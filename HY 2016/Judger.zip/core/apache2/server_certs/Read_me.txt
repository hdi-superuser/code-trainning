###############################################################################
# Name: Read_me.txt
# Created By: The Uniform Server Development Team
# Edited Last By: Mike Gleaves (ric)
# V 1.0 27-6-2011
###############################################################################

 Two files sub.class1.server.ca.pem and ca.pem are specific to StartSSL.com
 these have been included to allow easy set-up for a class 1 free
 certificate.

 Details are provided in the documentation.
 UniServer\docs\English\apache_free_server_cert.html

                                  --- End ---